/**
 * Logique principale de l'interface utilisateur.
 * Gère la navigation et les éléments communs comme le Loader.
 */

document.addEventListener('DOMContentLoaded', () => {
    // Injection dynamique de la barre de navigation
    // Cela évite de copier-coller le code HTML sur chaque page.
    const navbar = `
    <nav class="navbar">
        <a href="index.html" class="logo">
AppFoot
    </a>
        <ul class="nav-links">
            <li><a href="index.html" id="nav-home">Accueil</a></li>
            <li><a href="standings.html" id="nav-standings">Classement</a></li>
            <li><a href="team-builder.html" id="nav-builder">Créer mon équipe</a></li>
            <li><a href="search.html" id="nav-search">Recherche</a></li>
        </ul>
    </nav>
    `;
    document.body.insertAdjacentHTML('afterbegin', navbar);

    // Mise en surbrillance du lien actif dans la navigation
    const path = window.location.pathname;
    const page = path.split("/").pop() || 'index.html';
    const activeLink = document.querySelector(`.nav-links a[href="${page}"]`);
    if (activeLink) activeLink.classList.add('active');
});

/**
 * Affiche un indicateur de chargement dans un conteneur donné.
 * @param {string} containerId - L'ID de l'élément HTML où afficher le loader.
 */
function renderLoader(containerId) {
    const container = document.getElementById(containerId);
    if (container) {
        container.innerHTML = '<div class="loader">Chargement des données...</div>';
    }
}
