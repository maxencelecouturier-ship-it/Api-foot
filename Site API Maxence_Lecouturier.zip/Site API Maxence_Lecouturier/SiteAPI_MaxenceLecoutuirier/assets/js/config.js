/**
 * Fichier de Configuration
 * Contient les clés API, les URLs et les constantes de l'application.
 */
const CONFIG = {
    // Clé API fournie par l'utilisateur pour api-sports.io
    API_KEY: '9a83214b294f50ef91506840fe129438',
    
    // URL de base de l'API (Version 3)
    API_BASE_URL: 'https://v3.football.api-sports.io',
    
    // Drapeau pour utiliser des données factices (Mock) ou la vraie API.
    // METTRE À TRUE pour économiser le quota (100 requêtes/jour).
    // METTRE À FALSE pour utiliser la vraie API en production.
    USE_MOCK_DATA: false, 

    // IDs des ligues supportées (Top 5 Européen)
    LEAGUES: {
        LIGUE_1: 61,          // France
        PREMIER_LEAGUE: 39,   // Angleterre
        BUNDESLIGA: 78,       // Allemagne
        SERIE_A: 135,         // Italie
        LA_LIGA: 140          // Espagne
    },
    
    // Saison en cours (ou la plus récente disponible pour le plan gratuit)
    // Note: Le plan gratuit a parfois des restrictions sur l'année en cours.
    SEASON: 2023 
};
