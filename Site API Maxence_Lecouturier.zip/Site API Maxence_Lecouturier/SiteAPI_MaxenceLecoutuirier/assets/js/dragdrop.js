/**
 * DRAG & DROP - Constructeur d'équipe
 * Permet de glisser des joueurs depuis la liste vers le terrain
 */

document.addEventListener('DOMContentLoaded', async () => {
    const playersContainer = document.getElementById('players-container');
    
    // === CHARGEMENT DES JOUEURS ===
    // Récupère la liste des joueurs du PSG (Team 85, Ligue 1)
    // En mode réel : pourrait être dynamique ou basé sur les favoris de l'utilisateur
    const players = await api.fetch('players', { 
        season: CONFIG.SEASON, 
        league: 61,  // Ligue 1
        team: 85     // PSG
    });
    
    // === AFFICHAGE DES JOUEURS DRAGGABLES ===
    if (players && players.length > 0) {
        playersContainer.innerHTML = '';
        
        players.forEach((p, index) => {
            const player = p.player;
            
            // Création de la carte joueur
            const card = document.createElement('div');
            card.className = 'player-card';
            card.draggable = true; // ⚠️ CRUCIAL pour activer le drag HTML5
            card.id = `player-${index}`; // ID unique pour identifier le joueur
            
            card.innerHTML = `
                <img src="${player.photo}" alt="${player.name}">
                <div>
                    <strong>${player.name}</strong><br>
                    <small>${p.statistics[0].games.position}</small>
                </div>
            `;
            
            // Event: Début du glissement
            card.addEventListener('dragstart', dragStart);
            playersContainer.appendChild(card);
        });
    } else {
        // Gestion d'erreur si pas de données
        playersContainer.innerHTML = 'Erreur chargement joueurs ou quota dépassé.';
    }

    // === CONFIGURATION DES ZONES DE DÉPÔT (cercles sur le terrain) ===
    const zones = document.querySelectorAll('.pitch-player');
    zones.forEach(zone => {
        zone.addEventListener('dragover', dragOver);   // Pendant le survol
        zone.addEventListener('dragenter', dragEnter); // Entrée dans la zone
        zone.addEventListener('dragleave', dragLeave); // Sortie de la zone
        zone.addEventListener('drop', drop);           // Dépôt du joueur
    });
});

// === VARIABLE GLOBALE ===
// Garde en mémoire l'élément actuellement glissé
let draggedItem = null;

/**
 * EVENT: Début du glissement (dragstart)
 * Appelé quand l'utilisateur commence à glisser un joueur
 */
function dragStart(e) {
    draggedItem = this; // Sauvegarde l'élément glissé
    e.dataTransfer.setData('text/plain', this.id); // Stocke l'ID pour le drop
    
    // Effet visuel: rend le joueur semi-transparent pendant le glissement
    setTimeout(() => this.style.opacity = '0.5', 0);
}

/**
 * EVENT: Survol d'une zone (dragover)

 */
function dragOver(e) {
    e.preventDefault(); 
}

/**
 * EVENT: Entrée dans une zone (dragenter)
 * Effet visuel: agrandit le cercle et change la bordure en jaune
 */
function dragEnter(e) {
    e.preventDefault();
    this.style.transform = 'scale(1.1)';      // Agrandissement
    this.style.borderColor = 'yellow';        // Bordure jaune
}

/**
 * EVENT: Sortie de la zone sans drop (dragleave)
 * Annule l'effet visuel
 */
function dragLeave(e) {
    this.style.transform = 'scale(1)';              // Taille normale
    this.style.borderColor = 'var(--accent-color)'; // Bordure d'origine
}

/**
 * EVENT: Dépôt du joueur (drop)
 * Place la photo du joueur dans le cercle sur le terrain
 */
function drop(e) {
    e.preventDefault();
    
    // Reset du style de la zone
    this.style.transform = 'scale(1)';
    this.style.borderColor = 'var(--accent-color)';

    if (draggedItem) {
        // Clone la photo du joueur depuis la carte
        const img = draggedItem.querySelector('img').cloneNode(true);
        
        this.innerHTML = ''; // Efface le texte par défaut (ex: "GK", "ST")
        this.appendChild(img); // Ajoute la photo du joueur
        
        // Rend le joueur visible à nouveau dans la liste
        draggedItem.style.opacity = '1';
        draggedItem = null; // Reset de la variable globale
    }
}