// Classe gérant toutes les interactions avec l'API Football (api-sports.io)
 
class FootballAPI {
    constructor() {
        this.apiKey = CONFIG.API_KEY;
        this.baseUrl = CONFIG.API_BASE_URL;
        this.useMock = CONFIG.USE_MOCK_DATA; // Active/désactive les données fictives
        this.headers = {
            'x-apisports-key': this.apiKey
        };
    }

    /**
     * MÉTHODE PRINCIPALE - Fait un appel API réel ou mock selon config
     * @param {string} endpoint - Route API (ex: 'standings', 'fixtures')
     * @param {object} params - Paramètres de requête
     * @returns {Promise<Array>} - Données récupérées
     */
    async fetch(endpoint, params = {}) {
        // MODE MOCK : Utilise les fichiers JSON locaux pour éviter de consommer le quota API
        if (this.useMock) {
            return this.mockFetch(endpoint, params);
        }

        // MODE RÉEL : Appel HTTP vers l'API
        const url = new URL(`${this.baseUrl}/${endpoint}`);
        Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));

        try {
            console.log(`[API] Fetching ${url.toString()}`);
            const response = await fetch(url, { headers: this.headers });
            
            // Gestion des erreurs HTTP (404, 500, etc.)
            if (!response.ok) {
                console.error(`[API] HTTP Error: ${response.status} ${response.statusText}`);
                return [];
            }

            const data = await response.json();
            console.log('[API] Response received:', data);
            
            // GESTION DES ERREURS API (quota dépassé, clé invalide, etc.)
            if (data.errors && Object.keys(data.errors).length > 0) {
                console.error("API Error:", data.errors);
                
                // Alerte si limite de quota atteinte
                if (data.errors.rateLimit) {
                    alert("Limite d'API atteinte pour aujourd'hui !");
                }
                return [];
            }
            
            // Vérification que la réponse contient bien des données
            if (!data.response) {
                console.warn('[API] Pas de propriété response dans les données:', data);
                return [];
            }
            
            return data.response || [];
        } catch (error) {
            console.error('API Request failed:', error);
            return [];
        }
    }

    /**
     * MODE MOCK - Simule un appel API avec des fichiers JSON locaux
     * Utile pour développer sans consommer le quota de l'API
     */
    async mockFetch(endpoint, params) {
        // Simule un délai réseau réaliste (500ms)
        await new Promise(r => setTimeout(r, 500));
        
        console.log(`[MOCK] Fetching ${endpoint}`, params);

        // CLASSEMENTS : Charge le fichier standings-61.json
        if (endpoint === 'standings') {
            const data = await this.loadJSON('assets/data/standings-61.json');
            console.log('[MOCK] Standings data loaded:', data);
            return data.response || [];
        }

        // MATCHS : Charge le fichier fixtures-61.json
        if (endpoint === 'fixtures') {
            const data = await this.loadJSON('assets/data/fixtures-61.json');
            console.log('[MOCK] Fixtures data loaded:', data);
            return data.response || [];
        }

        // JOUEURS : Charge le fichier players-psg.json
        if (endpoint === 'players') {
            const data = await this.loadJSON('assets/data/players-psg.json');
            console.log('[MOCK] Players data loaded:', data);
            return data.response || [];
        }

        return [];
    }

    /**
     * UTILITAIRE - Charge un fichier JSON depuis le système de fichiers
     */
    async loadJSON(path) {
        try {
            console.log(`[MOCK] Loading JSON from: ${path}`);
            const response = await fetch(path);
            
            if (!response.ok) {
                console.error(`[MOCK] Failed to load ${path}: ${response.status} ${response.statusText}`);
                return { response: [] };
            }
            
            const data = await response.json();
            console.log(`[MOCK] JSON loaded from ${path}:`, data);
            return data;
        } catch (e) {
            console.error(`[MOCK] Erreur chargement ${path}:`, e);
            return { response: [] };
        }
    }

    // === MÉTHODES SPÉCIFIQUES PAR FONCTIONNALITÉ ===

    /**
     * CLASSEMENTS - Récupère le classement d'une ligue
     * @param {number} leagueId - ID de la ligue (ex: 61 pour Ligue 1)
     */
    async getStandings(leagueId) {
        // En mode mock, retourne toujours la Ligue 1 par simplicité
        if(this.useMock) {
             return this.fetch('standings', { season: CONFIG.SEASON, league: 61 });
        }
        return this.fetch('standings', { season: CONFIG.SEASON, league: leagueId });
    }

    /**
     * MATCHS - Récupère les matchs (passés ou à venir)
     * @param {number} leagueId - ID de la ligue
     * @param {boolean} live - Si true, récupère les 10 derniers matchs, sinon les 10 prochains
     */
    async getFixtures(leagueId, live = false) {
        let params = { season: CONFIG.SEASON, league: leagueId };
        
        if (live) {
            // L'API gratuite ne supporte pas toujours le vrai "live"
            // On demande les 10 derniers matchs pour avoir du contenu
            params.last = 10;
        } else {
            // Matchs à venir
            params.next = 10;
        }
        
        // En mode mock, retourne toujours les fixtures de la Ligue 1
        if (this.useMock) {
             return this.fetch('fixtures', { season: CONFIG.SEASON, league: 61 });
        }

        return this.fetch('fixtures', params);
    }
    
    /**
     * RECHERCHE JOUEURS - Trouve des joueurs par leur nom
     * Note: L'API nécessite obligatoirement un leagueId ou teamId
     * @param {string} query - Nom du joueur à chercher
     * @param {number} leagueId - ID de la ligue (défaut: Premier League)
     */
    async searchPlayers(query, leagueId = CONFIG.LEAGUES.PREMIER_LEAGUE) {
        if(this.useMock) {
            // MODE MOCK : Filtre localement dans le fichier players-psg.json
            const players = await this.fetch('players', { season: CONFIG.SEASON, league: 61, team: 85 });
            if(!players) return [];
            
            // Recherche case-insensitive dans les noms
            return players.filter(p => 
                p.player.name.toLowerCase().includes(query.toLowerCase())
            );
        }
        
        // MODE RÉEL : Appel API avec paramètre de recherche
        return this.fetch('players', { search: query, season: CONFIG.SEASON, league: leagueId });
    }
}

// === INSTANCE GLOBALE ===
// Créée automatiquement pour être utilisée partout dans l'app
const api = new FootballAPI();